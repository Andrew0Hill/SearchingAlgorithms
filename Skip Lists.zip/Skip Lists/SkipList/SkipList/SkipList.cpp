#include "SkipList.h"
#include <iostream>
#include <vector>

// Returns a random number of levels for a node given the probability between
// levels, p, and max_levels.
unsigned int randomLevels(float p = DEFAULT_P,
	                      int max_levels = DEFAULT_MAX_LEVELS)
{
	int levels = 1;
	if ((p==0.5) && (max_levels<=16))
		for (int r = rand(); (levels<max_levels) && (r%2==1); r>>=1, levels++);
	else
		for (; (levels<max_levels) && (random()<p); levels++);
	return levels;
}

// Constructs a new, empty link with a NULL cell and zero span.
IndexableSkipListLink::IndexableSkipListLink()
{
	cell = NULL;
	span = 0;
}

// Constructs a new skip list cell with the specified data and levels of
// links.
IndexableSkipListCell::IndexableSkipListCell(float data, int levels)
{
	this->data = data;
	next.resize(levels);
}

// Clears the next vector before deconstructing the cell.
IndexableSkipListCell::~IndexableSkipListCell()
{
	next.clear();
}

// Returns the ith skip list cell of the indexable skip list.
IndexableSkipListCell * IndexableSkipList::CellRef(int i)
{
	int dist = -1;
	IndexableSkipListCell * curr_cell = NULL;
	for (int level = max_levels-1; level>=0 && dist<i; level--) {
		//if (dist==i) break;
		while (true) {
			IndexableSkipListLink next_link =
				(curr_cell==NULL) ? first[level] : curr_cell->next[level];
			IndexableSkipListCell * next_cell = next_link.cell;
			if ((next_cell==NULL) || (dist+next_link.span>i)) break;
			curr_cell = next_cell;
			dist += next_link.span;
		}
	}
	return curr_cell;
}

// Constructs a new empty indexable skip list with the specified probability
// between levels, p, and max_levels.
IndexableSkipList::IndexableSkipList(float p, int max_levels)
{
	this->p = p;
	this->max_levels = max_levels;
	n = 0;
	first.resize(max_levels);
}

// Deletes all of skip list cells and clear the first vector before the
// indexable skip list is deconstructed.
IndexableSkipList::~IndexableSkipList()
{
	// Deletes all of the skip list cells.
	IndexableSkipListCell * prev_cell = NULL;
	IndexableSkipListCell * next_cell = first[0].cell;
	while (next_cell!=NULL) {
		prev_cell = next_cell;
		next_cell = next_cell->next[0].cell;
		delete prev_cell;
	}
	// Clear the first vector.
	first.clear();
}

// Inserts data into the indexable skip list.
void IndexableSkipList::Insert(float data)
{
	// Loop through each level - from highest to lowest - accumulating
	// previous cell pointers and the distance traveled along each level.
	vector<IndexableSkipListCell *> prev(max_levels, NULL);
	vector<int> dist(max_levels, 0);
	IndexableSkipListCell * curr_cell = NULL;
	for (int level = max_levels-1; level>=0; level--) {
		while (true) {
			prev[level] = curr_cell;
			IndexableSkipListLink next_link =
				(curr_cell==NULL) ? first[level] : curr_cell->next[level];
			IndexableSkipListCell * next_cell = next_link.cell;
			if ((next_cell==NULL) || !(next_cell->data < data)) break;
			curr_cell = next_cell;
			dist[level] += next_link.span;
		}
	}
	// Insert a new cell with a random number of levels. Iterate through
	// these levels - accumulating the total distance - and compute the
	// spans for the links. The span from the new cell to a next cell is the
	// (old) span from the previous cell to the next cell minus the
	// cumulative distance or zero for null links. The span from the
	// previous cell to the next cell is the cumulative distance plus one.
	int levels = randomLevels(p, max_levels);
	IndexableSkipListCell * cell = new IndexableSkipListCell(data, levels);
	for (int cumm_dist = 0, level = 0;
		level < levels;
		cumm_dist += dist[level], level++){
		if (prev[level]==NULL) {
			cell->next[level].cell = first[level].cell;
			if (cell->next[level].cell!=NULL)
				cell->next[level].span = first[level].span-cumm_dist;
			first[level].cell = cell;
			first[level].span = cumm_dist+1;
		}
		else {
			cell->next[level].cell = prev[level]->next[level].cell;
			if (cell->next[level].cell!=NULL)
				cell->next[level].span =
				prev[level]->next[level].span-cumm_dist;
			prev[level]->next[level].cell = cell;
			prev[level]->next[level].span = cumm_dist+1;
		}
	}
	// Iterate through the rest of the levels adding one to each non-null
	// link. Note that the inner ifs don't have elses and therefore the
	// braces are required.
	for (int level = levels; level<max_levels; level++) {
		if (prev[level]==NULL) {
			if (first[level].cell!=NULL) first[level].span += 1; }
		else {
			if (prev[level]->next[level].cell!=NULL)
				prev[level]->next[level].span += 1; }
	}
	// Increment the length of the skip list.
	n += 1;
}

// Returns the ith and (i+1)th elements of the indexable skip list by
// reference in the left and right arguments.
void IndexableSkipList::RefPair(int i, float &left, float &right)
{
	IndexableSkipListCell * cell = CellRef(i);
	left = cell->data;
	right = cell->next[0].cell->data;
}

// Prints the indexable skip list by level with the spans for each link.
void IndexableSkipList::Print()
{
	for (int level = 0; level<max_levels; level++){
		cout << level << ": ";
		for (IndexableSkipListLink link = first[level];
			 link.cell!=NULL; link = link.cell->next[level])
			cout << "-(" << link.span << ")-> " << link.cell->data << " ";
		cout << "\n";
	}
}