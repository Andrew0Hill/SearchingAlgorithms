#include "SkipList.h"
#include "Quartiles.h"
#include <iostream>
#include <time.h>

int main ()
{
	Quartiles * qstat = NULL;
	// Randomize the random number generator.
	srand((unsigned)time(0)); 
	// Print the skip list and quartile statistics for 13 random floats.
	qstat = new Quartiles();
	for (int i = 0; i<13; i++) qstat->Tally((float)rand()*random());
	qstat->data->Print();
	cout << "n=" << qstat->n << "\n";
	cout << "min=" << qstat->min << "\n";
	cout << "max=" << qstat->max << "\n";
	cout << "Q1=" << qstat->Q1 << "\n";
	cout << "Q2=" << qstat->Q2 << "\n";
	cout << "Q3=" << qstat->Q3 << "\n";
	cout << "IQR=" << qstat->IQR << "\n";
	delete qstat;
	// Test CB sized data sets.
	for (int test=0; test<1000; test++) {
		qstat = new Quartiles();
		int n = rand()/16;
		for (int i = 0; i<n; i++) qstat->Tally((float)rand()*random());
		cout << "test " << test << ", n=" << n << ", IQR=" << qstat->IQR << "\n";
		delete qstat;
	}
	// Stress test the quartile and skip list implementations.
	for (int test=0; test<1000; test++) {
		qstat = new Quartiles();
		int n = rand()*10;
		for (int i = 0; i<n; i++) qstat->Tally((float)rand()*random());
		cout << "test " << test << ", n=" << n << ", IQR=" << qstat->IQR << "\n";
		delete qstat;
	}
	return 0;
}