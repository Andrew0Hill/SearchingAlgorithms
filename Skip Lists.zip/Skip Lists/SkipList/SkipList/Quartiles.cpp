#include "Quartiles.h"
#include "SkipList.h"
#include <limits>

// Efficiently compute the specified quantile, f, of the skip list data. The
// quantile is between 0 and 1.
float Quantile(IndexableSkipList * skip_list, float f)
{
	int n = skip_list->Length();
	float index = f*(float)(n-1);
	int lhs = (int)index;
	float delta = index-lhs;
	if (lhs==n-1)
		return skip_list->Ref(lhs);
	else {
		float left, right;
		skip_list->RefPair(lhs, left, right);
		return (1-delta)*left+delta*right;
	}
}

// Constructs a new, empty running quartiles analysis. The mininum and maximum
// varlues are set at the opposite extreme float value. The quartiles and inter-
// quartile range (IQR) are set to not-a-number. And, a new, empty skip list
// is created to hold the data elements.
Quartiles::Quartiles()
{
	n = 0;
	min = numeric_limits<float>::max();
	max = numeric_limits<float>::min();
	data = new IndexableSkipList();
	Q1 = numeric_limits<float>::quiet_NaN();
	Q2 = numeric_limits<float>::quiet_NaN();
	Q2 = numeric_limits<float>::quiet_NaN();
	IQR = numeric_limits<float>::quiet_NaN();
}

// Clears the skip list before destroying the running quartile analysis.
Quartiles::~Quartiles()
{
	delete data;
	data = NULL;
}

// Updates the running quartile analysis with the data element, x. The minimum
// and maximum values are updated, if necessary. The data element is added to
// the skip list. And, the quartiles and IQR are computed.
void Quartiles::Tally(float x)
{
	n += 1;
	if (x<min) min = x;
	if (x>max) max = x;
	data->Insert(x);
	Q1 = Quantile(data, 0.25);
	Q2 = Quantile(data, 0.50);
	Q3 = Quantile(data, 0.75);
	IQR = Q3-Q1;
}
