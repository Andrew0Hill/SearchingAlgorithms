#ifndef QUARTILES_H
#define QUARTILES_H

#include "SkipList.h"

// Running quartiles analysis efficiently computes the 25th, 50th, and 75th
// percentiles for an evolving data set. The number of elements and the minimum
// and maximum values are also computed.
struct Quartiles {
	int n;
	IndexableSkipList * data;
	float min;
	float max;
	float Q1;
	float Q2;
	float Q3;
	float IQR;

public:

	// Constructs a new, empty running quartiles analysis.
	Quartiles();

	// Clears the skip list before destroying the running quartile analysis.
	~Quartiles();

	// Updates the running quartile analysis with the data element, x.
	void Tally(float x);

};

#endif
