#ifndef SKIPLIST_H
#define SKIPLIST_H

#include <cstdlib>
#include <vector>
using namespace std;

// Note that the random generation capability provided by Microsoft Visual C++
// is pretty bad with RAND_MAX=32767, but suffices for our use here.

// Returns a random float between 0 and 1.
inline
float random()
{
	return ((float)rand()/(float)(RAND_MAX+1));
}

// The default probability between levels.
#define DEFAULT_P 0.5

// The default maximum number of levels.
#define DEFAULT_MAX_LEVELS 16

// Incomplete declaration of IndexableSkipListCell for forward reference.
struct IndexableSkipListCell;

// An IndexableSkipListLink is a link to a skip list cell and the span for the
// link, which is the total distance of that link at level zero.
struct IndexableSkipListLink {
	IndexableSkipListCell * cell;
	int span;

public:

	// Constructs a new, empty link with a NULL cell and zero span.
	IndexableSkipListLink();
};

// An IndexableSkipListCell is the data for an element and a vector of next
// links.
struct IndexableSkipListCell {
	float data;
	vector<IndexableSkipListLink> next;

public:

	// Constructs a new skip list cell with the specified data and levels of
	// links.
	IndexableSkipListCell(float data, int levels);

	// Clears the next vector before deconstructing the cell.
	~IndexableSkipListCell();
};

// An IndexableSkipList is a sorted list of elements with expected O(log n)
// insertions and references. This implementation uses float data elements.
class IndexableSkipList {

private:

	float p;
	int max_levels;
	int n;
	vector<IndexableSkipListLink> first;

	// Returns the ith skip list cell of the indexable skip list.
	IndexableSkipListCell * CellRef(int i);

public:

	// Constructs a new empty indexable skip list with the specified probability
	// between levels, p, and max_levels.
	IndexableSkipList(float p = DEFAULT_P, int max_levels = DEFAULT_MAX_LEVELS);

	// Deletes all of skip list cells and clear the first vector before the
	// indexable skip list is deconstructed.
	~IndexableSkipList();

	// Returns the length of the indexable skip list.
	int Length() { return n; }

	// Inserts data into the indexable skip list.
	void Insert(float data);

	// Returns the ith element of the indexable skip list.
	float Ref(int i) { return CellRef(i)->data; }

	// Returns the ith and (i+1)th elements of the indexable skip list by
	// reference in the left and right arguments.
	void RefPair(int i, float &left, float &right);

	// Prints the indexable skip list by level with the spans for each link.
	void Print();
};

#endif